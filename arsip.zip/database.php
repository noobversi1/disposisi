<?php
$koneksi = "localhost";
$user = "root";
$pass = "";
$db = "disposisi";
